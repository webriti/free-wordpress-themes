<!-- Page Section -->
<div class="container">
	<div class="row">
		<div class="page_title">
				<h1><?php the_title(); ?></h1>		
		</div>
	</div>
</div>