<form class="elitepress-search"  action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
<input type="text" class="search_widget_input"  name="s" id="s" placeholder="<?php esc_attr_e( "Search", 'elitepress' ); ?>" />
</form>