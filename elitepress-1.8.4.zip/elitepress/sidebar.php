<!--Sidebar Area-->
<?php if(is_active_sidebar( 'sidebar_primary' )){ ?>
			<?php dynamic_sidebar( 'sidebar_primary' );	?>
<?php } ?>
<!--Sidebar Area-->