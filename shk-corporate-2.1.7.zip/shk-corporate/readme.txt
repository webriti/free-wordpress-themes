=======================================================
   Shk Corporate
=======================================================

Thank you for downloading Our theme. 
This and any other Theme provided by me should
be free of bugs, however, if something goes wrong, or you 
need our assistance with anything, you can mail me at themes@webriti.com

If you need help with the Lite (free) version of this theme,
please click on the theme you are using from my WordPress
Profile page, then click on the support tab for the theme.

=======================================================
    License
=======================================================

Shk Corporate WordPress Theme, Copyright 2017 Webriti
www.webriti.com

Shk Corporate is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY.

To view an updated version of the GPL License, see http://www.gnu.org/copyleft/gpl.html.

-------------------------------------------------------
    Theme Support
-------------------------------------------------------

If you need theme support, please use the "support" tab on the theme's
page here: 

https://wordpress.org/themes/shk-corporate


-------------------------------------------------------
    Photo Credits:
-------------------------------------------------------
Shk Corporate screenshot photo:

Screenshot Image : CCO by Unsplash
Screenshot Image URl: https://pixabay.com/en/workplace-team-business-meeting-1245776/

-------------------------------------------------------
    Parent Theme Credits:
-------------------------------------------------------
	https://wordpress.org/themes/appointment/
	License: GPL


-------------------------------------------------------
    Font Credits:
-------------------------------------------------------

(1) Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
	License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
	Source: http://fontawesome.io
	
(2) Open Sans Font by Steve Matteson - https://fonts.google.com/specimen/Open+Sans
	License: Apache License, version 2.0 (http://www.apache.org/licenses/LICENSE-2.0.html)	

-------------------------------------------------------
    Bootstrap Credit:
-------------------------------------------------------

(1)	Bootstrap v3.1.1 (http://getbootstrap.com) | Copyright 2011-2014 Twitter, Inc.
	Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE

-------------------------------------------------------
    Change Log:
-------------------------------------------------------
@Version 2.0
1. Added Header Sidebar.

@Version 2.1
1. Update Pagiantion Color.

@Version 2.1.1
1. Updated Strings

@Version 2.1.2
1. Revise Upgrade To Pro link.

@Version 2.1.3
1. Added dummy data import setting.

@Version 2.1.4
1. Update Author URI and Theme URI change http to https secure.

@Version 2.1.5
1. Update String.

@Version 2.1.6
1. Update String.

@Version 2.1.7
1. Add alt tag on logo.