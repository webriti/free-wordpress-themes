﻿Qality Theme README.

A Business Blog theme that supports Primary menu's , Primary sidebar,Four widgets area at the footer region  etc. 
It has a perfect design that's great for any Business/Firms  Blogs who wants a new look for their site. 
Qality supports featured slider managed from Theme Option Panel.

Author: Webriti

About:
Qality a theme for business, consultancy firms etc  by Webriti (Author URI: http://www.webriti.com). 

The CSS, XHTML and design is released under GPL:
http://www.opensource.org/licenses/gpl-license.php

Feel free to use as you please. I would be very pleased if you could keep the Author-link in the footer. Thanks and enjoy.

Appoinment supports Custom Menu, Widgets and 
the following extra features:

 - Pre-installed menu and content
 - Responsive
 - Custom sidebars
 - Support for post thumbnails
 - Similar posts feature
 - 4 widgetized areas in the footer
 - Customise Front Page 
 - Custom footer
 - Translation Ready 
 

# Basic Setup of the Theme.
-----------------------------------
Fresh installation!

1. Upload the Qality Theme folder to your wp-content/themes folder.
2. Activate the theme from the WP Dashboard.
3. Done!
=== Images ===

All images in Qality are licensed under the terms of the GNU GPL.

# Top Navigation Menu:
- Default the page-links start from the left! Use the Menus function in Dashboard/Appearance to rearrange the buttons and build your own Custom-menu. DO NOT USE LONG PAGE NAMES, Maximum 14 letters/numbers incl. spaces!
- Read more here: http://codex.wordpress.org/WordPress_Menu_User_Guide

=============Setting Option Panel======================
$$$$$$ Homepage Setting $$$$$$


1. Disable Front Page:- BY Defalult the themes customize Front page is displayed when the theme  installed for the first time.
			If you want to enable wordpress reading settinsg than disable this option.

2. Adding Logo:-	Upload the site logo from here also you can adjust the width and height of logo from the logo height and width fields.

3.Text Title as a logo:-  If just want to show text title instead of image logo than enable this setting and some text to the wordpress Site Title.

4.Custom Favicon:- 	Theme also support favicons. You can add your own favicon ico from here Please make sure thatyou only upload .ico image type.

5. Custom Css:-  	This is the nice feature added along with the theme, you can add your style rules form here. No need to use thirdparty plugin for doing so.


$$$$$$$ Service Section $$$$$$$$
1.Enable Service Section:- Service Section is found on the custom front page. This setting is on by default. If you dont want to show service section on front page 
			   Than disable this option.In the lite verison you are only allowed to add 4 services.

2.Service Icon:-	Font Awesome service icons are used here. Just specify the font awesoe icon name.

3.Service Title:-	Set Service Title here.

4. Service Description :-  Add information related to services.

Similarly  add more services.

$$$$ Footer Setting $$$$$
1. Enable/Disable footer Widgets:-  As the name suggest this setting will add an extra bit of functionality to add / remove widgets feature.

2. Credit Links:-  From the footer settings you can set the credit links like copyright, powered bye tc. If you dont want to use designed by link
		   than leave that option as blank. 
		   
		   
		   
License
-------

Quality WordPress Theme, Copyright 2014 Priyanshu Mittal
Quality is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Quality WordPress Theme bundles the following third-party resources:

* Font Awesome http://fontawesome.github.io/Font-Awesome/
 * Font License
    Applies to all desktop and webfont files in the following directory: font-awesome/fonts/.
    License: SIL OFL 1.1
    URL: http://scripts.sil.org/OFL
 * Code License
    Applies to all CSS and LESS files in the following directories: font-awesome/css/, font-awesome/less/, and font-awesome/scss/.
    License: MIT License
    URL: http://opensource.org/licenses/mit-license.html

JavaScripts		
		1. Bootstrap.min.js => https://github.com/twbs/bootstrap/releases/download/v3.1.1/bootstrap-3.1.1-dist.zip
                   Code and documentation copyright 2011-2014 Twitter, Inc. Code released under the MIT license. Docs released under Creative Commons.
		
	Images
		1. Screenshot Image => https://www.pexels.com/photo/man-and-woman-in-front-of-laptop-computer-1065704/
		2. Static Home Feature Image => https://pixabay.com/en/vw-camper-volkswagen-vw-car-336606/
		3. Product Image
		   https://pixabay.com/en/sofa-couch-surreal-eyes-dog-art-749629/
		   https://pixabay.com/en/tablet-living-room-dog-woman-girl-843798/
		   https://pixabay.com/en/tablet-ipad-read-screen-swipe-1075790/
		   https://pixabay.com/en/business-hard-working-autonomous-1067978/
		4. Demo Images
			https://www.pexels.com/photo/attractive-beautiful-beauty-fashion-206470/
			https://www.pexels.com/photo/action-automotive-car-employee-279949/
			https://www.pexels.com/photo/adult-backpack-bicycle-bike-281967/
			https://www.pexels.com/photo/adult-aperture-bokeh-camcorder-289796/
			https://www.pexels.com/photo/adult-business-desk-document-296886/
			https://www.pexels.com/photo/portrait-of-young-woman-drinking-coffee-at-home-324030/
			https://www.pexels.com/photo/blank-business-composition-computer-373076/
			https://www.pexels.com/photo/cafe-camera-classic-close-up-413960/
			https://www.pexels.com/photo/bag-brown-eyewear-fashion-426862/
			https://www.pexels.com/photo/adult-beard-board-boy-450278/

		images are licensed under GPL.
		
Font Awesome...
Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
Source: http://fontawesome.io
		   
CSS Tooltips by Adam Whitcroft
https://github.com/AdamWhitcroft/CSS.Tooltips
Licensed under â˜º License.
----------------------------------------------------------------------			


Support
-------

Do you enjoy this theme? Send your ideas - issues - on the theme forum . Thank you!

ChangLog:

@Version 2.5.1
1. Remove custom-header code from functions.php file.
@Version 2.5
1. Remove Site favicon setting from Header setting in customizer.
2. Move Header logo setting from Header settings to Site identity.
3. Add page builder templates.
4. Update About quality theme option page.
@Version 2.4.1
1. Remove unnecessary HTML markup.
2. Add breadcrumb section in 404 page.
@Version 2.4
Remove Lock Icons and Create list of features mentioned in View PRO details tab.
@Version 2.3.2.1
Added upgrade to pro link in missing pro settings.
@Version 2.3.2
Added the customizer selective refresh for the footer copyright.
@Version 2.3.1
Corrected Sanitization issue
@version 2.3
1. Remove duplicate post title on single view.
2. Add homepage section ON/OFF setting.
@version 2.2.7
1. Some small changes.
@version 2.2.6.1
1. Added Bitbucket theme URI.
@version 2.2.6
1. Added filter for demo switcher.
2. Fixed some menu style issue.
@version 2.2.5
1. Fixed Menu Issue.
@version 2.2.4
1. Fixed Menu Issue.
@version 2.2.3
1. Update string.
@version 2.2.2
1. Added WooCommerce Gallery Support.
@Version 2.2.1
1. Update Slider Read more link.
2. Added Recommended action tab in about theme page.
3. Update doc link.
@Version 2.2
1. Update Links.
@Version 2.1
1. Remove demo preview image.
@Version 2.0
1. Added  Testimonial Section.
2. Update Whole Theme Design. 
@Version 1.9.7
1. Update Get started Style. 
@Version 1.9.6
1. Strings Updated
@Version 1.9.5
1. Strings Updated
@Version 1.9.4
1. Strings Updated
@Version 1.9.3
1. Strings Updated
@Version 1.9.2
1. Strings Updated
@Version 1.9.1
1.Change message text.
2.Fixed styling issue.
@Version 1.9
1.Added repetater customize control in service section.
@Version 1.8.1
1.Update screen reader css.
@Version 1.8
1.Update demo preview images on wordpress.org
@Version 1.7.9
1. Added Demo images for wordpress preview.
@Version 1.7.8
1. Updated Theme URI & Author URI 
@Version 1.7.7
1. Added Getting starded button in customize setting for use our homepage .
@Version 1.7.6
1. Fixed styling issue.
@Version 1.7.5
1. Update pot file for theme info.
@Version 1.7.4
1. Updated Strings.
@Version 1.7.3
1. Update Font Awesome Icon 4.6.1 to 4.6.3
2. Add blog, portfolio, footer-widgets, right-sidebar Tag.
3. Add Title Tag.
4. Add About Quality Theme Setting
@Version 1.7.2
1. Remove Parallax Pro demo Link in Customizer.
2. Solved Styling issue.
@Version 1.7.1
1. Changed Theme Description in style.css File.
@Version 1.7
1.add footer widget area and change screenshot
@Version 1.6
1.Remove Page Author Meta.
2.Remove empty wrapper of feature image when there is no feature image
3.Remove Top border from the content in pages.
4.Add Full Width Template
5.Add button in banner image.
6.Remove empty wrapper of content when there is no content.
7.Change menu font size and align.
8.Added galary image css.
9.Added contact form 7 css.
10.Fixed banner image description issue.
@Version 1.5.4
1. Solved Theme Review Issue.
2. Update Font awesome Icon 4.5 to 4.6.1
@Version 1.5.3
1. Add Parallax Demo Link.
@Version 1.5.2
1. Change Product Image
2. Font awesome Icon Folder 4.4.0 to 4.5.0
@Version 1.5.1
1. Comments Author Issue resolved.
@Version 1.5
1. Styling issue fixed.
2. Remove Copyright text file.
@Version 1.4
1. Add Google Font.
2. Css Minified
@Version 1.3.2
1. Add Pro Feature For Demo
2. Remove Title Tag.
@Version 1.3.1
1. Update Font-awesome Folder.
2. Fixed Theme Check Error.
@Version 1.3
1. Fixed Styling issue
2. Fixed Front page issue.
3. Add HTML Sanitization copyright and blog section.
@Version 1.2
customizer added
@version 1.1
1. All social links initialised with the # value.
2. Remove console errors.
3. Remove all debug errors.
4. removed default widgets.

@VErsion 1.0.6.6
1. Managed Front Page.
@Version 1.0.6.5
1. Remove all undefined index errors
@verison 1.0.6.4
1. copyright attribution corrected
2. Escaped favicon url.
@version 1.0.6.3
1. css in footer passed through html special chars funcitons
2. esc url called wherever required.
3. license added for the image shown in screenshot.
4. Added sub title on banner.
@version 1.0.6.2
1. the_excerpt filter called to add class to default paragraph tag.
2. Description text added over the banner.
3. Setting for adding content in the banner description.
4. Page layouts managed, page/posts/  goes to full width when sidebar is not active.
5. Project bug fixed as indicated by the users.
@version 1.0.6
1. Default-Logo Will appear
2. Changes for Custom CSS.
3. Content Width Issue Fixed.
@version 1.0.5
1.	NEW WLAKER CLASS ADDED FOR BOOTSTRAP-3. 
@version 1.0.4
1.	Small Changes in Comment Form
@version 1.0.3
1.	HTML beautified Code.
@version 1.0.2.1
1. front-page.php added.
2. project sections added.
3. blog section of home page added.
@version 1.0.2
1.Removed unused resources.
@version 1.0.1
1.W3C validate
@Version 1.0
released

# --- EOF --- #
